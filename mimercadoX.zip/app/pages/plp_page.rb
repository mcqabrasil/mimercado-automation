# Class to get the elements content
class PlpPage
  include Capybara::DSL

  # Buttons
  PRODUCT_FROM_LIST = 'productLink'
end
