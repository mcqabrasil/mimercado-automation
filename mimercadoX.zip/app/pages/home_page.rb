# Class to get the elements content
class HomePage
  include Capybara::DSL
  
  # LINKS
  PRODUCT_LINK = '.product-item' # CLASS
  

end


