require_relative '../page methods/home_met'

class HomeAssertions 
  include Capybara::DSL
  include RSpec::Matchers

  def initialize
    @home = HomeMethods.new
  end


end
