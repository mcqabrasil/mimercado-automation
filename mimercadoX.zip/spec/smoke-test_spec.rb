require_relative '../app/page methods/cart_met'
require_relative '../app/page methods/home_met'
require_relative '../app/assertions/cart_assert'
require_relative '../app/assertions/header_assert'
require_relative '../app/assertions/footer_assert'
require_relative '../app/assertions/pdp_assert'

describe 'test' do
  before(:all) do
   # @cart = CartMethods.new
    @cart_as = CartAssertions.new
    @header_as = HeaderAssertions.new
    @footer_as = FooterAssertions.new
    @home_met = HomeMethods.new
    @pdp_as = PDPAssertions.new

    visit '/'
  end

  context "Check Home page, Header and Footer links", :SMOKE_01 do
    it 'Header should be present with its components', :SMOKE_01_step1 do
      @header_as.assert_header_visible
      @header_as.assert_logo_visible
      @header_as.assert_cart_price_visible
      @header_as.assert_cart_icon_visible
      @header_as.assert_search_visible
      @header_as.assert_menu_btn_visible
    end

    it 'Footer should be present with its components', :SMOKE_01_step2 do

    end

    it 'Product links should take user to the given PDP', :SMOKE_01_step3 do
      @home_met.click_product_link(2)
      @pdp_as.assert_pdp_div_presence
      # assert by url in PDP should be checked, cause it does not have a standard
    end

    it "'Ver todos los produtos' link should take user to the PLP", :SMOKE_01_step4 do

    end

    it '', :SMOKE_01_step5 do

    end

    it '', :SMOKE_01_step6 do

    end

    it '', :SMOKE_01_step7 do

    end

    it '', :SMOKE_01_step8 do

    end

    it '', :SMOKE_01_step9 do

    end

    it '', :SMOKE_01_step10 do

    end

    it '', :SMOKE_01_step11 do

    end

    it '', :SMOKE_01_step12 do

    end

    it '', :SMOKE_01_step13 do

    end

    it '', :SMOKE_01_step14 do

    end

    it '', :SMOKE_01_step15 do

    end

    it '', :SMOKE_01_step16 do

    end

    it '', :SMOKE_01_step17 do

    end


  end
end
